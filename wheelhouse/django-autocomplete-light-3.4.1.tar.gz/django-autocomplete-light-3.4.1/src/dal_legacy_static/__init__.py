"""Static files for Django < 2.0."""
