"""django-generic-m2m support for DAL."""
